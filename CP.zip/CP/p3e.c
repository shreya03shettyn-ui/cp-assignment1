//logical operator
#include<stdio.h>
int main()
{
int a=0,b=5;
  printf("\n output=%d",a&&b);
  printf("\n output=%d",a||b);
  printf("\n output=%d",!b);
  return 0;
}
