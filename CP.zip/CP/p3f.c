//conditional operator
#include<stdio.h>
int main()
{
 int a=10,b=5,c;
 c=(a>b)?a:b;
 printf("c=%d",c);
 return 0;

}
