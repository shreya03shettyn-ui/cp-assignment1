//size of character
#include<stdio.h>
int main()
{
   int a;
   float b;
   double c;
   char d;
   printf("\n sizeof=%d",sizeof(int));
   printf("\n sizeof=%d",sizeof(float));
   printf("\n sizeof=%d",sizeof(double));
   printf("\n sizeof=%d",sizeof(char));
   return 0;
}
