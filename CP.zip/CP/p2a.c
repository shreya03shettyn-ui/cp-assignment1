//to print differnt data types
#include<stdio.h>
int main()
{
 int i=123456;
 char c='A';
 float f=3.14f;
 double d=3.1415926535;
 char str[]="hello ,world!";
 printf("int:%d \n ",i);
 printf("char:%c \n ",c);
 printf("float:%%.2f \n ",f);
 printf("double:%.10f \n ",d);
 printf("string:%s \n ",str);
 return 0;
 }
