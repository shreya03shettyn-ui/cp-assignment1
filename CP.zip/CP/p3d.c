//relational and logical
#include<stdio.h>
int main()
{
int a=10,b=9;
  printf("\n output=%d",(a<b)&&(a||b));
  printf("\n output=%d",(a>b)&&(a=b));
  printf("\n %d",a);
  printf("\n output=%d",(!a)||(!b));
  return 0;
  }
