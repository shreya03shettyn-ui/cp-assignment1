//+ve or -ve
#include<stdio.h>
int main()
{
int a;
   printf("enter the value of a");
   scanf("%d",&a);
if(a>0)
  printf("the given value %d is +ve",a);
return 0;
}
