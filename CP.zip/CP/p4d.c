//nested if
#include<stdio.h>
int main()
{
 int a=9,b=7;
   if(a>0)
   {
     if(b>0)
     printf("a and b are positive");
   }
   return 0;
}
