//reciving input from user at runtime
#include<stdio.h>
int main()
{
 int roll,age;
 printf("\n enter your age");
 scanf("%d",&age);
 printf("\n enter your roll number");
 scanf("%d",&roll);
 printf("\n entered age is=%d",age);
 printf("\n entered roll number is=%d",roll);
 return 0;
 }
