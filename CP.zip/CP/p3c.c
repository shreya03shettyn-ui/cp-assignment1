//increment,decrement operator
#include<stdio.h>
int main()
{
  int a=10;
  printf("\n post increement=%d",a++);
  printf("\n post decreement=%d",a--);
  printf("\n pre increement=%d",++a);
  printf("\n pre decreement=%d",--a);
  return 0;
  }
