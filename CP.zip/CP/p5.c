//ARITHMETIC OPERATION
#include<stdio.h>
int main()
{
int a=10,b=4;
  printf("\n addition of two values is=%d",a+b);
  printf("\n subtraction of two values is=%d",a-b);
  printf("\n multiplication of two values is=%d",a*b);
  printf("\n division of two values is=%d",a/b);
  printf("\n modulus of two values is=%d",a%b);
  return 0;
  }
